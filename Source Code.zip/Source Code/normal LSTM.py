# libraries
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout

# load data 
data = pd.read_csv("C:/Users/Atoz Ady/OneDrive - ums.edu.my/FINAL YEAR PROJECT/TrafficVolumeData.csv")

data.head()
# data cleaning
# Check for missing values
print(data.isnull().sum())

# Handle missing values (adjust as needed)
data.fillna(0, inplace=True)  # Replace missing values with 0

# Verify data types
print(data.dtypes)

# Try different date_time formats until successful conversion (handle potential errors)
formats = ["%d/%m/%Y %H:%M", "%Y-%m-%d %H:%M", "%m/%d/%Y"]
for format in formats:
  try:
    data['date_time'] = pd.to_datetime(data['date_time'], format=format)
    break  # Exit the loop if conversion is successful
  except pd.errors.ParserError:
    pass  # Continue to the next format if parsing fails

# Check if conversion was successful (optional)
if not pd.api.types.is_datetime64_dtype(data['date_time']):
  print("Warning: Could not convert date_time column. Check format and adjust as needed.")

# Extract features from date_time (assuming successful conversion)
if pd.api.types.is_datetime64_dtype(data['date_time']):
  data['hour'] = data['date_time'].dt.hour
  data['day_of_week'] = data['date_time'].dt.dayofweek
  data['month'] = data['date_time'].dt.month

# Drop original date_time column (if no longer needed)
data = data.drop(columns=['date_time'])

# Feature Engineering
# Replace 'No' with 0 and other values with 1 in 'is_holiday'
data['is_holiday'] = data['is_holiday'].apply(lambda x: 0 if x == 'No' else 1)

# Encode Categorical Variables
label_encoder = LabelEncoder()
data['is_holiday'] = label_encoder.fit_transform(data['is_holiday'])
data['weather_type'] = label_encoder.fit_transform(data['weather_type'])
data['weather_description'] = label_encoder.fit_transform(data['weather_description'])

# Bin Traffic Volume into Categories
data['traffic_volume_binned'] = pd.qcut(data['traffic_volume'], q=3, labels=['low', 'medium', 'high'])

# Separate Features and Target Variable
X = data.drop(columns=['traffic_volume', 'traffic_volume_binned'])  # Features
y = data['traffic_volume_binned']  # Target variable (binned)

print(data.head())

# normalize numerical features
scaler = MinMaxScaler()
X[['air_pollution_index', 'humidity', 'wind_speed', 'visibility_in_miles', 'dew_point', 'temperature', 'rain_p_h', 'snow_p_h', 'clouds_all']] = scaler.fit_transform(X[['air_pollution_index', 'humidity', 'wind_speed', 'visibility_in_miles', 'dew_point', 'temperature', 'rain_p_h', 'snow_p_h', 'clouds_all']])

# Convert target variable to numerical representation (e.g., one-hot encoding)
y = pd.get_dummies(y)

#time series data 
window_size = 24  # Adjust window size as needed
X_ts = []
y_ts = []
for i in range(window_size, len(X)):
    X_ts.append(X[i-window_size:i])
    y_ts.append(y.iloc[i])

X_ts = np.array(X_ts)
y_ts = np.array(y_ts)

# data splitting 
X_train, X_test, y_train, y_test = train_test_split(X_ts, y_ts, test_size=0.2, random_state=42)

# LSTM model 
model = Sequential()
model.add(LSTM(units=64, return_sequences=True, input_shape=(window_size, X.shape[1])))
model.add(Dropout(0.2))
model.add(LSTM(units=32))
model.add(Dropout(0.2))
model.add(Dense(y.shape[1], activation='softmax'))
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# model training 
model.fit(X_train, y_train, epochs=20, batch_size=32, validation_data=(X_test, y_test))

# model prediction 
y_pred = model.predict(X_test)

# model performance
accuracy = accuracy_score(y_test.argmax(axis=1), y_pred.argmax(axis=1))
precision = precision_score(y_test.argmax(axis=1), y_pred.argmax(axis=1), average='weighted')
recall = recall_score(y_test.argmax(axis=1), y_pred.argmax(axis=1), average='weighted')
f1 = f1_score(y_test.argmax(axis=1), y_pred.argmax(axis=1), average='weighted')

print("Accuracy:", accuracy)
print("Precision:", precision)
print("Recall:", recall)
print("F1-score:", f1)
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# Compute the confusion matrix
conf_matrix = confusion_matrix(y_test.argmax(axis=1), y_pred.argmax(axis=1))

# Print the confusion matrix
print("Confusion Matrix:")
print(conf_matrix)

# Visualize the confusion matrix as a heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Reds', 
            xticklabels=['low', 'medium', 'high'], 
            yticklabels=['low', 'medium', 'high'])
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()
