# Libraries
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report, ConfusionMatrixDisplay
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.impute import SimpleImputer
import matplotlib.pyplot as plt

# Load the data
data = pd.read_csv("C:/Users/Atoz Ady/OneDrive - ums.edu.my/FINAL YEAR PROJECT/TrafficVolumeData.csv")

# Handle missing values
data.fillna(0, inplace=True)  # Replace missing values with 0

# Date conversion
formats = ["%d/%m/%Y %H:%M", "%Y-%m-%d %H:%M", "%m/%d/%Y"]
for format in formats:
    try:
        data['date_time'] = pd.to_datetime(data['date_time'], format=format)
        break
    except:
        pass

if pd.api.types.is_datetime64_dtype(data['date_time']):
    data['hour'] = data['date_time'].dt.hour
    data['day_of_week'] = data['date_time'].dt.dayofweek
    data['month'] = data['date_time'].dt.month

data = data.drop(columns=['date_time'])  # Drop the date column

# Feature Engineering
data['is_holiday'] = data['is_holiday'].apply(lambda x: 0 if x == 'No' else 1)
label_encoder = LabelEncoder()
data['weather_type'] = label_encoder.fit_transform(data['weather_type'])
data['weather_description'] = label_encoder.fit_transform(data['weather_description'])

# Bin Traffic Volume into Categories
data['traffic_volume_binned'] = pd.qcut(data['traffic_volume'], q=3, labels=['low', 'medium', 'high'])

# Prepare Features and Target
X = data.drop(columns=['traffic_volume', 'traffic_volume_binned'])
y = data['traffic_volume_binned']
y_onehot = pd.get_dummies(y)

# Normalize numerical features
scaler = MinMaxScaler()
X[['air_pollution_index', 'humidity', 'wind_speed', 'visibility_in_miles', 'dew_point', 'temperature',
   'rain_p_h', 'snow_p_h', 'clouds_all']] = scaler.fit_transform(X[['air_pollution_index', 'humidity',
   'wind_speed', 'visibility_in_miles', 'dew_point', 'temperature', 'rain_p_h', 'snow_p_h', 'clouds_all']])

# 1. Train LSTM Model
# Prepare time-series data for LSTM
window_size = 24
X_ts, y_ts = [], []
for i in range(window_size, len(X)):
    X_ts.append(X[i-window_size:i])
    y_ts.append(y_onehot.iloc[i])

X_ts = np.array(X_ts)
y_ts = np.array(y_ts)

# Train-test split
X_train_ts, X_test_ts, y_train_ts, y_test_ts = train_test_split(X_ts, y_ts, test_size=0.2, random_state=42)

# LSTM Model
lstm_model = Sequential([
    LSTM(units=64, return_sequences=True, input_shape=(window_size, X.shape[1])),
    Dropout(0.2),
    LSTM(units=32),
    Dropout(0.2),
    Dense(y_onehot.shape[1], activation='softmax')
])
lstm_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
lstm_model.fit(X_train_ts, y_train_ts, epochs=20, batch_size=32, validation_data=(X_test_ts, y_test_ts))

# Predict with LSTM
y_pred_lstm = lstm_model.predict(X_test_ts)

# Define y_true for the test set
y_true = y_test_ts.argmax(axis=1)

# Evaluate LSTM Model
y_pred_lstm_class = np.argmax(y_pred_lstm, axis=1)
accuracy_lstm = accuracy_score(y_true, y_pred_lstm_class)
precision_lstm = precision_score(y_true, y_pred_lstm_class, average='weighted')
recall_lstm = recall_score(y_true, y_pred_lstm_class, average='weighted')
f1_lstm = f1_score(y_true, y_pred_lstm_class, average='weighted')

print("LSTM Model Performance:")
print(f"Accuracy: {accuracy_lstm:.4f}")
print(f"Precision: {precision_lstm:.4f}")
print(f"Recall: {recall_lstm:.4f}")
print(f"F1-score: {f1_lstm:.4f}")

# Confusion Matrix for LSTM
cm_lstm = confusion_matrix(y_true, y_pred_lstm_class)
disp_lstm = ConfusionMatrixDisplay(confusion_matrix=cm_lstm, display_labels=['low', 'medium', 'high'])
disp_lstm.plot(cmap='viridis')
plt.title("Confusion Matrix - LSTM Model")
plt.show()

# 2. Train GBM Model
# Flatten time-series data for GBM
X_train_flat = X_train_ts.reshape(X_train_ts.shape[0], -1)
X_test_flat = X_test_ts.reshape(X_test_ts.shape[0], -1)

# Impute missing values
imputer = SimpleImputer(strategy="mean")
X_train_flat = imputer.fit_transform(X_train_flat)
X_test_flat = imputer.transform(X_test_flat)

# Train GBM
gbm_model = GradientBoostingClassifier(n_estimators=30, learning_rate=0.1)
gbm_model.fit(X_train_flat, y_train_ts.argmax(axis=1))
y_pred_gbm_proba = gbm_model.predict_proba(X_test_flat)

# Convert GBM probabilities to class predictions
y_pred_gbm_class = np.argmax(y_pred_gbm_proba, axis=1)

# Evaluate GBM Model
accuracy_gbm = accuracy_score(y_true, y_pred_gbm_class)
precision_gbm = precision_score(y_true, y_pred_gbm_class, average='weighted')
recall_gbm = recall_score(y_true, y_pred_gbm_class, average='weighted')
f1_gbm = f1_score(y_true, y_pred_gbm_class, average='weighted')

print("\nGBM Model Performance:")
print(f"Accuracy: {accuracy_gbm:.4f}")
print(f"Precision: {precision_gbm:.4f}")
print(f"Recall: {recall_gbm:.4f}")
print(f"F1-score: {f1_gbm:.4f}")

# Confusion Matrix for GBM
cm_gbm = confusion_matrix(y_true, y_pred_gbm_class)
disp_gbm = ConfusionMatrixDisplay(confusion_matrix=cm_gbm, display_labels=['low', 'medium', 'high'])
disp_gbm.plot(cmap='viridis')
plt.title("Confusion Matrix - GBM Model")
plt.show()

# 3. Ensemble Voting
weight_lstm = 0.3
weight_gbm = 0.7
ensemble_pred_proba = (weight_lstm * y_pred_lstm) + (weight_gbm * y_pred_gbm_proba)
ensemble_pred = np.argmax(ensemble_pred_proba, axis=1)

# Evaluate Ensemble Model
accuracy = accuracy_score(y_true, ensemble_pred)
precision = precision_score(y_true, ensemble_pred, average='weighted')
recall = recall_score(y_true, ensemble_pred, average='weighted')
f1 = f1_score(y_true, ensemble_pred, average='weighted')

print("\nEnsemble Model Performance:")
print(f"Accuracy: {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1-score: {f1:.4f}")

# Confusion Matrix for Ensemble
cm_ensemble = confusion_matrix(y_true, ensemble_pred)
disp_ensemble = ConfusionMatrixDisplay(confusion_matrix=cm_ensemble, display_labels=['low', 'medium', 'high'])
disp_ensemble.plot(cmap='viridis')
plt.title("Confusion Matrix - Ensemble Model")
plt.show()
