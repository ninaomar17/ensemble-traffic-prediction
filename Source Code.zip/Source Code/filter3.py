import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, ConfusionMatrixDisplay
from sklearn.ensemble import GradientBoostingClassifier
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from kerastuner import HyperModel, RandomSearch

# Load data
data = pd.read_csv("C:/Users/Atoz Ady/OneDrive - ums.edu.my/FINAL YEAR PROJECT/TrafficVolumeData.csv")

# Data cleaning
data.fillna(0, inplace=True)

# DateTime conversion
formats = ["%d/%m/%Y %H:%M", "%Y-%m-%d %H:%M", "%m/%d/%Y"]
for fmt in formats:
    try:
        data['date_time'] = pd.to_datetime(data['date_time'], format=fmt)
        break
    except (pd.errors.ParserError, ValueError):
        pass

if pd.api.types.is_datetime64_dtype(data['date_time']):
    data['hour'] = data['date_time'].dt.hour
    data['day_of_week'] = data['date_time'].dt.dayofweek
    data['month'] = data['date_time'].dt.month

data = data.drop(columns=['date_time'])

# Feature engineering
data['is_holiday'] = data['is_holiday'].apply(lambda x: 0 if x == 'No' else 1)
label_encoder = LabelEncoder()
data['weather_type'] = label_encoder.fit_transform(data['weather_type'])
data['weather_description'] = label_encoder.fit_transform(data['weather_description'])
data['traffic_volume_binned'] = pd.qcut(data['traffic_volume'], q=3, labels=['low', 'medium', 'high'])

# Separate features and target variable
X = data.drop(columns=['traffic_volume', 'traffic_volume_binned'])
y = data['traffic_volume_binned']

# Encode target variable for GBM
y_encoded = y.map({'low': 0, 'medium': 1, 'high': 2})

# Analyze class distribution
import matplotlib.pyplot as plt

# Display class counts
class_counts = y.value_counts()
print("Class Distribution:\n", class_counts)

# Plot the class distribution
class_counts.plot(kind='bar', color=['purple', 'blue', 'pink'], title='Class Distribution')
plt.xlabel('Traffic Volume Bins')
plt.ylabel('Count')
plt.show()

# Correlation-based feature selection
correlation_matrix = pd.DataFrame(X).assign(target=y_encoded).corr()
correlation_with_target = correlation_matrix["target"].drop("target")
selected_features = correlation_with_target[correlation_with_target.abs() > 0.1].index.tolist()

X_selected = X[selected_features]

# Normalize the features
scaler = MinMaxScaler()
X_selected = scaler.fit_transform(X_selected)

# Convert the target variable to numerical for the LSTM model
y_one_hot = pd.get_dummies(y)

# Time series data preparation for LSTM
window_size = 24
X_ts = []
y_ts = []
for i in range(window_size, len(X_selected)):
    X_ts.append(X_selected[i-window_size:i])
    y_ts.append(y_one_hot.iloc[i])

X_ts = np.array(X_ts)
y_ts = np.array(y_ts)

# Split the data for training and testing
X_train, X_test, y_train, y_test = train_test_split(X_ts, y_ts, test_size=0.2, random_state=42)
X_train_gbm, X_test_gbm, y_train_gbm, y_test_gbm = train_test_split(X_selected[window_size:], y_encoded[window_size:], test_size=0.2, random_state=42)

# Hyperparameter tuning for Gradient Boosting
param_grid = {
    'n_estimators': [50, 100, 150],
    'learning_rate': [0.01, 0.1, 0.2],
    'max_depth': [3, 5, 7],
    'min_samples_split': [2, 5, 10]
}

gbm_grid_search = GridSearchCV(estimator=GradientBoostingClassifier(), 
                                param_grid=param_grid, 
                                scoring='accuracy', 
                                cv=3, 
                                verbose=1, 
                                n_jobs=-1)

gbm_grid_search.fit(X_train_gbm, y_train_gbm)
print("Best parameters for Gradient Boosting:", gbm_grid_search.best_params_)
gbm_model = gbm_grid_search.best_estimator_

# Hyperparameter tuning for LSTM
class LSTMHyperModel(HyperModel):
    def build(self, hp):
        model = Sequential()
        model.add(LSTM(units=hp.Int('units_1', min_value=32, max_value=128, step=32), 
        return_sequences=True, input_shape=(window_size, X_selected.shape[1])))
        model.add(Dropout(hp.Float('dropout_1', 0.1, 0.5, step=0.1)))
        model.add(LSTM(units=hp.Int('units_2', min_value=16, max_value=64, step=16)))
        model.add(Dropout(hp.Float('dropout_2', 0.1, 0.5, step=0.1)))
        model.add(Dense(y_one_hot.shape[1], activation='softmax'))
        model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
        return model

checkpoint_callback = ModelCheckpoint(
    filepath='lstm_best_weights.weights.h5',  # Corrected to end with .weights.h5
    save_best_only=True,
    save_weights_only=True,
    monitor='val_loss',
    verbose=1
)



early_stopping = EarlyStopping(
    monitor='val_loss',
    patience=5,
    verbose=1,
    restore_best_weights=True
)

lstm_tuner = RandomSearch(
    LSTMHyperModel(),
    objective='val_accuracy',
    max_trials=10,
    executions_per_trial=1,
    directory='lstm_tuner',
    project_name='traffic_volume_lstm'
)

lstm_tuner.search(X_train, y_train, epochs=20, batch_size=32, validation_split=0.2, callbacks=[checkpoint_callback, early_stopping])

best_hps = lstm_tuner.get_best_hyperparameters(num_trials=1)[0]

# Rebuild and train the best LSTM model
best_lstm_model = Sequential()
best_lstm_model.add(LSTM(units=best_hps.get('units_1'), return_sequences=True, input_shape=(window_size, X_selected.shape[1])))
best_lstm_model.add(Dropout(best_hps.get('dropout_1')))
best_lstm_model.add(LSTM(units=best_hps.get('units_2')))
best_lstm_model.add(Dropout(best_hps.get('dropout_2')))
best_lstm_model.add(Dense(y_one_hot.shape[1], activation='softmax'))
best_lstm_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

best_lstm_model.fit(X_train, y_train, epochs=20, batch_size=32, validation_data=(X_test, y_test), callbacks=[checkpoint_callback, early_stopping])

# Predictions and evaluations
def evaluate_model(model_name, y_true, y_pred):
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='weighted')
    recall = recall_score(y_true, y_pred, average='weighted')
    f1 = f1_score(y_true, y_pred, average='weighted')
    print(f"\n{model_name} Performance Metrics:")
    print("Accuracy:", accuracy)
    print("Precision:", precision)
    print("Recall:", recall)
    print("F1-score:", f1)
    print("\nClassification Report:\n", classification_report(y_true, y_pred))
    # Confusion matrix
    ConfusionMatrixDisplay.from_predictions(y_true, y_pred, display_labels=['low', 'medium', 'high'])
    plt.title(f'{model_name} Confusion Matrix')
    plt.show()
# LSTM
y_pred_prob_lstm = best_lstm_model.predict(X_test)
y_pred_lstm = np.argmax(y_pred_prob_lstm, axis=1)
y_true_lstm = np.argmax(y_test, axis=1)
evaluate_model("LSTM Model", y_true_lstm, y_pred_lstm)

# Gradient Boosting
y_pred_gbm = gbm_model.predict(X_test_gbm)
evaluate_model("Gradient Boosting Model", y_test_gbm, y_pred_gbm)

# Weighted Voting Ensemble
weight_lstm = 0.3  # Weight for LSTM predictions
weight_gbm = 0.7   # Weight for GBM predictions

y_pred_prob_combined = (weight_lstm * y_pred_prob_lstm) + (weight_gbm * gbm_model.predict_proba(X_test_gbm))
y_pred_ensemble = np.argmax(y_pred_prob_combined, axis=1)
evaluate_model("Ensemble Model", y_true_lstm, y_pred_ensemble)
