import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report
from sklearn.ensemble import GradientBoostingClassifier
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import ModelCheckpoint
from kerastuner import HyperModel, RandomSearch
from sklearn.feature_selection import RFE

# Load data
data = pd.read_csv("C:/Users/Atoz Ady/OneDrive - ums.edu.my/FINAL YEAR PROJECT/TrafficVolumeData.csv")

# Data cleaning
data.fillna(0, inplace=True)

# DateTime conversion
formats = ["%d/%m/%Y %H:%M", "%Y-%m-%d %H:%M", "%m/%d/%Y"]
for format in formats:
    try:
        data['date_time'] = pd.to_datetime(data['date_time'], format=format)
        break
    except (pd.errors.ParserError, ValueError):
        pass

if pd.api.types.is_datetime64_dtype(data['date_time']):
    data['hour'] = data['date_time'].dt.hour
    data['day_of_week'] = data['date_time'].dt.dayofweek
    data['month'] = data['date_time'].dt.month

data = data.drop(columns=['date_time'])

# Feature engineering
data['is_holiday'] = data['is_holiday'].apply(lambda x: 0 if x == 'No' else 1)
label_encoder = LabelEncoder()
data['weather_type'] = label_encoder.fit_transform(data['weather_type'])
data['weather_description'] = label_encoder.fit_transform(data['weather_description'])
data['traffic_volume_binned'] = pd.qcut(data['traffic_volume'], q=3, labels=['low', 'medium', 'high'])

# Separate features and target variable
X = data.drop(columns=['traffic_volume', 'traffic_volume_binned'])
y = data['traffic_volume_binned']

# Encode target variable for GBM
y_encoded = y.map({'low': 0, 'medium': 1, 'high': 2})

# Step 1: Correlation-based filtering
correlation_threshold = 0.9
correlation_matrix = X.corr()
correlated_features = set()

for i in range(len(correlation_matrix.columns)):
    for j in range(i):
        if abs(correlation_matrix.iloc[i, j]) > correlation_threshold:
            col_name = correlation_matrix.columns[i]
            correlated_features.add(col_name)

filtered_features = [col for col in X.columns if col not in correlated_features]

# Step 2: RFE for feature selection
rfe_model = GradientBoostingClassifier(n_estimators=30, learning_rate=0.1)
rfe = RFE(estimator=rfe_model, n_features_to_select=5)
rfe.fit(X, y_encoded)
rfe_features = X.columns[rfe.support_]

# Step 3: Combine feature sets
# Intersection (common features)
combined_features = list(set(filtered_features) & set(rfe_features))

# Alternatively, union (all features selected by either method)
#combined_features = list(set(filtered_features) | set(rfe_features))

# Subset data with combined features
X_combined = X[combined_features]

# Normalize combined features
scaler = MinMaxScaler()
X_combined = scaler.fit_transform(X_combined)

# Convert the target variable to one-hot encoding for LSTM
y_one_hot = pd.get_dummies(y)

# Time series data preparation for LSTM
window_size = 24
X_ts_combined = []
y_ts_combined = []
for i in range(window_size, len(X_combined)):
    X_ts_combined.append(X_combined[i - window_size:i])
    y_ts_combined.append(y_one_hot.iloc[i])

X_ts_combined = np.array(X_ts_combined)
y_ts_combined = np.array(y_ts_combined)

# Train-test split
X_train_combined, X_test_combined, y_train_combined, y_test_combined = train_test_split(
    X_ts_combined, y_ts_combined, test_size=0.2, random_state=42
)

X_train_gbm_combined, X_test_gbm_combined, y_train_gbm_combined, y_test_gbm_combined = train_test_split(
    X_combined[window_size:], y_encoded[window_size:], test_size=0.2, random_state=42
)

# Hyperparameter tuning and training for Gradient Boosting
gbm_model_combined = GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, max_depth=5)
gbm_model_combined.fit(X_train_gbm_combined, y_train_gbm_combined)

# Hyperparameter tuning and training for LSTM
class LSTMHyperModel(HyperModel):
    def build(self, hp):
        model = Sequential()
        model.add(LSTM(units=hp.Int('units_1', min_value=32, max_value=128, step=32), return_sequences=True, input_shape=(window_size, X_combined.shape[1])))
        model.add(Dropout(hp.Float('dropout_1', 0.1, 0.5, step=0.1)))
        model.add(LSTM(units=hp.Int('units_2', min_value=16, max_value=64, step=16)))
        model.add(Dropout(hp.Float('dropout_2', 0.1, 0.5, step=0.1)))
        model.add(Dense(y_one_hot.shape[1], activation='softmax'))
        model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
        return model

checkpoint_callback = ModelCheckpoint(
    filepath='lstm_best_weights.weights.h5',
    save_best_only=True,
    save_weights_only=True,
    monitor='val_loss',
    verbose=1
)

lstm_tuner = RandomSearch(
    LSTMHyperModel(),
    objective='val_accuracy',
    max_trials=10,
    executions_per_trial=1,
    directory='lstm_tuner',
    project_name='traffic_volume_lstm'
)

lstm_tuner.search(X_train_combined, y_train_combined, epochs=20, batch_size=32, validation_split=0.2, callbacks=[checkpoint_callback])

best_lstm_model_combined = lstm_tuner.get_best_models(num_models=1)[0]
best_lstm_model_combined.fit(X_train_combined, y_train_combined, epochs=20, batch_size=32, validation_data=(X_test_combined, y_test_combined))

# Predictions and evaluations
def evaluate_model(model_name, y_true, y_pred):
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='weighted')
    recall = recall_score(y_true, y_pred, average='weighted')
    f1 = f1_score(y_true, y_pred, average='weighted')
    print(f"\n{model_name} Performance Metrics:")
    print("Accuracy:", accuracy)
    print("Precision:", precision)
    print("Recall:", recall)
    print("F1-score:", f1)
    print("\nClassification Report:\n", classification_report(y_true, y_pred))

# LSTM
y_pred_prob_lstm_combined = best_lstm_model_combined.predict(X_test_combined)
y_pred_lstm_combined = np.argmax(y_pred_prob_lstm_combined, axis=1)
y_true_lstm_combined = np.argmax(y_test_combined, axis=1)

y_pred_gbm_combined = gbm_model_combined.predict(X_test_gbm_combined)

# Weighted Voting
weight_lstm = 0.5
weight_gbm = 0.5

y_pred_prob_combined = (weight_lstm * y_pred_prob_lstm_combined) + (weight_gbm * gbm_model_combined.predict_proba(X_test_gbm_combined))
y_pred_ensemble_combined = np.argmax(y_pred_prob_combined, axis=1)

evaluate_model("Ensemble (Correlation + RFE)", y_true_lstm_combined, y_pred_ensemble_combined)
